import  React, {useState} from 'react';
import { Text, View, StyleSheet, TextInput } from 'react-native';
import Festa from './components/Festa';

export default function App() {
  const [valor, setValor] = useState(0);
  return (
    <View style={styles.container}>
     <Text style={styles.titulo}> Festa </Text>

     <Text style={styles.subtitulo}> Numero de pessoas </Text>

     <View style={styles.convite}>
        <TextInput
          value={valor}
          onChangeText={(value)=>setValor(value)}
        />     
     </View>

     <Festa pessoas = {valor}/>
    </View>
  );
}

const styles = StyleSheet.create({
  titulo:{
    fontSize: 50,
    color: '#5B2C6F',
    marginBottom: 15,
  },

    subtitulo:{
      fontSize: 23,
      marginBottom: 20
    },

  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#3498DB',
  },

  convite:{
    borderWidth: 3,
    borderRadius: '100px',
    borderColor: '#8E44AD',
    width: '80%',
    marginBottom: 20
  },

 
});
