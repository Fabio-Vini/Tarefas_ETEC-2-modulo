import * as React from 'react';
import { Text, View, StyleSheet} from 'react-native';

export default function Festa(props) {
  
  return (
   <>
   <View style={styles.info}>

    <View style={styles.texto}>
      <Text> Refrigerante: {(props.pessoas * 600)} ml </Text>
    </View>

    <View>
      <Text style={styles.texto}> Água: {(props.pessoas * 200)} ml </Text>
    </View>

    <View>
      <Text style={styles.texto}> Bolo: {(props.pessoas * 100)/1000} kg </Text>
    </View>

    <View style={styles.texto}>
      <Text> Doce: {(props.pessoas * 3)} unidades </Text>
    </View>

    <View style={styles.texto}>
      <Text> Salgadinhos: {(props.pessoas * 10)} unidades </Text>
    </View>
    
    </View>
   </>
  );
}

const styles = StyleSheet.create({
  info:{
    alignItems: 'center'

  },

  texto:{
    marginBottom:30,
  }
 
});
