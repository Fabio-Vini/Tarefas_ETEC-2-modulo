﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        public struct Data
        {
            public int Dia, Mes, Ano;
        }
        static void Main(string[] args)
        {
            Data dataNasc;

            Console.WriteLine("Data do seu nascimento");
            Console.Write("Dia: ");
            dataNasc.Dia = int.Parse(Console.ReadLine());

            Console.Write("Mês: ");
            dataNasc.Mes = int.Parse(Console.ReadLine());

            Console.Write("Ano: ");
            dataNasc.Ano = int.Parse(Console.ReadLine());

           if(dataNasc.Dia >=1 && dataNasc.Dia <=31 && dataNasc.Mes == 1|| dataNasc.Mes ==3 || dataNasc.Mes == 5 || dataNasc.Mes == 7 || dataNasc.Mes == 8 || dataNasc.Mes == 10 || dataNasc.Mes == 12 && dataNasc.Ano <= 2022)
            {
                Console.WriteLine("A data digita foi {0}/{1}/{2} e é valida",dataNasc.Dia,dataNasc.Mes,dataNasc.Ano);
            }
           else if(dataNasc.Dia >= 1 && dataNasc.Dia <= 30 && dataNasc.Mes == 4 || dataNasc.Mes == 6 || dataNasc.Mes == 9 || dataNasc.Mes == 11 && dataNasc.Ano <= 2022)
            {
                Console.WriteLine("A data digita foi {0}/{1}/{2} e é valida", dataNasc.Dia, dataNasc.Mes, dataNasc.Ano);
            }
           else if(dataNasc.Dia >=1 && dataNasc.Dia <=29 && dataNasc.Mes==2 && dataNasc.Ano % 400 == 0 || dataNasc.Ano % 4 == 0 && dataNasc.Ano * 100 != 0 && dataNasc.Ano<=2022)
            {
                Console.WriteLine("A data digita foi {0}/{1}/{2} e é valida", dataNasc.Dia, dataNasc.Mes, dataNasc.Ano);
                Console.WriteLine("O ano inserido é bissexto");
            }
           else
            {
                Console.WriteLine("A data inserida é invalida");
                Console.WriteLine("ou o ano inserido não é existente");
            }
            Console.WriteLine("\n\nAperte qualquer tecla para fecar o console");
                Console.ReadKey();
        }
    }
}